#include <device.h>
//#include <i2c.h>
#include <gpio.h>
//#include <misc/byteorder.h>
#include <misc/util.h>
#include <kernel.h>
#include <sensor.h>
#include <misc/__assert.h>

#include "hcsr04_drv.h"

// int tmp007_reg_read(struct tmp007_data *drv_data, u8_t reg, u16_t *val)
// {
// 	struct i2c_msg msgs[2] = {
// 		{
// 			.buf = &reg,
// 			.len = 1,
// 			.flags = I2C_MSG_WRITE | I2C_MSG_RESTART,
// 		},
// 		{
// 			.buf = (u8_t *)val,
// 			.len = 2,
// 			.flags = I2C_MSG_READ | I2C_MSG_STOP,
// 		},
// 	};
//
// 	if (i2c_transfer(drv_data->i2c, msgs, 2, TMP007_I2C_ADDRESS) < 0) {
// 		return -EIO;
// 	}
//
// 	*val = sys_be16_to_cpu(*val);
//
// 	return 0;
// }
//
// int tmp007_reg_write(struct tmp007_data *drv_data, u8_t reg, u16_t val)
// {
// 	u8_t tx_buf[3] = {reg, val >> 8, val & 0xFF};
//
// 	return i2c_write(drv_data->i2c, tx_buf, sizeof(tx_buf),
// 			 TMP007_I2C_ADDRESS);
// }
//
// int tmp007_reg_update(struct tmp007_data *drv_data, u8_t reg,
// 		      u16_t mask, u16_t val)
// {
// 	u16_t old_val = 0;
// 	u16_t new_val;
//
// 	if (tmp007_reg_read(drv_data, reg, &old_val) < 0) {
// 		return -EIO;
// 	}
//
// 	new_val = old_val & ~mask;
// 	new_val |= val & mask;
//
// 	return tmp007_reg_write(drv_data, reg, new_val);
// }
//
 static int hcsr04_sample_fetch(struct device *dev, enum sensor_channel chan)
 {
// 	struct tmp007_data *drv_data = dev->driver_data;
// 	u16_t val;
//
// 	__ASSERT_NO_MSG(chan == SENSOR_CHAN_ALL || chan == SENSOR_CHAN_TEMP);
//
// 	if (tmp007_reg_read(drv_data, TMP007_REG_TOBJ, &val) < 0) {
// 		return -EIO;
// 	}
//
// 	if (val & TMP007_DATA_INVALID_BIT) {
// 		return -EIO;
// 	}
//
// 	drv_data->sample = arithmetic_shift_right((s16_t)val, 2);
//
 	return 0;
 }
//
 static int hcsr04_channel_get(struct device *dev,
 			       enum sensor_channel chan,
 			       struct sensor_value *val)
 {
	 printk("inside channel get function\n");
// 	struct tmp007_data *drv_data = dev->driver_data;
// 	s32_t uval;
//
// 	if (chan != SENSOR_CHAN_TEMP) {
// 		return -ENOTSUP;
// 	}
//
// 	uval = (s32_t)drv_data->sample * TMP007_TEMP_SCALE;
// 	val->val1 = uval / 1000000;
// 	val->val2 = uval % 1000000;
//
 	return 0;
 }

static const struct sensor_driver_api hcsr04_driver_api = {
	//.attr_set = hcsr04_attr_set,
	//.trigger_set = tmp007_trigger_set,
	.sample_fetch = hcsr04_sample_fetch,
	.channel_get = hcsr04_channel_get,
};

int hcsr04_init(struct device *dev)
{
	struct hcsr04_data *drv_data = dev->driver_data;
	printk("inside hcsr04_init function\n");

	dev->driver_api = &hcsr04_driver_api;

	// drv_data->i2c = device_get_binding(CONFIG_TMP007_I2C_MASTER_DEV_NAME);
	// if (drv_data->i2c == NULL) {
	// 	SYS_LOG_DBG("Failed to get pointer to %s device!",
	// 		    CONFIG_TMP007_I2C_MASTER_DEV_NAME);
	// 	return -EINVAL;
	// }

	return 0;
}

struct hcsr04_data hcsr04_driver;

DEVICE_INIT(HCSR_0, CONFIG_HCSR04_0_NAME, hcsr04_init, &hcsr04_driver,
		    NULL, POST_KERNEL, CONFIG_SENSOR_INIT_PRIORITY);
