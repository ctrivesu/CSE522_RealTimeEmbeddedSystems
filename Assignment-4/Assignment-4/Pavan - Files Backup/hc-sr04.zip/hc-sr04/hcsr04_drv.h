#ifndef _SENSOR_HCSR04
#define _SENSOR_HCSR04

#include <device.h>
#include <gpio.h>
#include <misc/util.h>

struct hcsr04_data{
	struct device *dev;
	
};



#endif
